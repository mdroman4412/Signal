import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  marketData: defineTable({
    pair: v.string(), // e.g., "EUR/CAD"
    price: v.number(),
    timestamp: v.number(), // Unix timestamp
  }).index("by_pair", ["pair"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
