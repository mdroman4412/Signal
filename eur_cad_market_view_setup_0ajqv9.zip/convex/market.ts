import { query } from "./_generated/server";
import { v } from "convex/values";

export const listMarketData = query({
  args: { pair: v.string() },
  handler: async (ctx, args) => {
    const data = await ctx.db
      .query("marketData")
      .withIndex("by_pair", (q) => q.eq("pair", args.pair))
      .order("desc") // Show most recent first
      .take(100); // Limit to 100 data points for now
    return data;
  },
});

// We can add a mutation to add data later when integrating a real API
// import { mutation } from "./_generated/server";
// export const addMarketDataPoint = mutation({
//   args: {
//     pair: v.string(),
//     price: v.number(),
//   },
//   handler: async (ctx, args) => {
//     await ctx.db.insert("marketData", {
//       pair: args.pair,
//       price: args.price,
//       timestamp: Date.now(),
//     });
//   },
// });
