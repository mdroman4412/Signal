import { useQuery } from "convex/react";
import { api } from "../convex/_generated/api";

// Example data for initial rendering
const exampleEurCadData = [
  { _id: "1", pair: "EUR/CAD", price: 1.475, timestamp: Date.now() - 300000 },
  { _id: "2", pair: "EUR/CAD", price: 1.476, timestamp: Date.now() - 240000 },
  { _id: "3", pair: "EUR/CAD", price: 1.474, timestamp: Date.now() - 180000 },
  { _id: "4", pair: "EUR/CAD", price: 1.4755, timestamp: Date.now() - 120000 },
  { _id: "5", pair: "EUR/CAD", price: 1.4758, timestamp: Date.now() - 60000 },
  { _id: "6", pair: "EUR/CAD", price: 1.4762, timestamp: Date.now() },
];

export function MarketView() {
  // Attempt to fetch real data, fallback to example data if empty or loading
  const marketData = useQuery(api.market.listMarketData, { pair: "EUR/CAD" });

  const dataToDisplay = marketData === undefined || marketData.length === 0 
    ? exampleEurCadData 
    : marketData;

  if (marketData === undefined) {
    return (
      <div className="flex justify-center items-center p-4">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        <p className="ml-2 text-secondary">Loading market data...</p>
      </div>
    );
  }

  return (
    <div className="p-4 bg-white shadow-md rounded-lg">
      <h3 className="text-2xl font-semibold text-primary mb-4">
        EUR/CAD Market View
      </h3>
      {dataToDisplay.length === 0 && marketData && ( // marketData is not undefined here
        <p className="text-secondary">
          No market data available for EUR/CAD. Displaying example data.
        </p>
      )}
       {dataToDisplay === exampleEurCadData && (
        <p className="text-sm text-orange-500 mb-2">
          Note: Displaying example data. Real data integration is pending.
        </p>
      )}
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th
                scope="col"
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
              >
                Time
              </th>
              <th
                scope="col"
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
              >
                Price (EUR/CAD)
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {dataToDisplay.map((dataPoint) => (
              <tr key={dataPoint._id.toString()}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {new Date(dataPoint.timestamp).toLocaleTimeString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {dataPoint.price.toFixed(4)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
